import React, { Component } from 'react';
import './style.scss';

class Detail extends Component {
    render() {
        return (
            <div className="top-header">Detail</div>
        )
    }
}

export default Detail;