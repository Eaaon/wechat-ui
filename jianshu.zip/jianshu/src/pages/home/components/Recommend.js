import React, { PureComponent } from 'react';
import { connect } from 'react-redux';

class Recommend extends PureComponent {
	render() {
		return (
			<recommend-wrapper>
				{
					this.props.list.map((item) => {
						return <div className="recommend-item " key={item.get('id')}> <img src={item.get('imgUrl')} alt=""></img></div>
					})
				}
			</recommend-wrapper>
		)
	}
}

const mapState = (state) => ({
	list: state.getIn(['home', 'recommendList'])
})

export default connect(mapState, null)(Recommend);