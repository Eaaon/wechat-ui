import React, { PureComponent } from 'react';

class Writer extends PureComponent {

	render() {
		return (
			<div className="writer-wrapper">HomeWork</div>
		)
	}
}

export default Writer;
