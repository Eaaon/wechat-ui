export const CHANGE_HOME_DATA = 'home/CHANGE_HOME_DATA';
export const ADD_ARTICLE_LIST = 'home/ADD_ARTICLE_LIST';
export const TOGGLE_SCROLL_TOP = 'home/TOGGLE_SCROLL_TOP';