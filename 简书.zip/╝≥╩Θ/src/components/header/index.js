import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Input } from 'antd';
import { InfoCircleOutlined } from '@ant-design/icons';
import './style.scss';
import 'antd/dist/antd.css';
import { actionCreators } from './store';

class Header extends Component {
    // constructor(props) {
    //     super(props); 
    //     this.handleInputFocus = this.handleInputFocus.bind(this);
    // }

    render() {
        const { focused, handleInputFocus, handleInputBlur } = this.props;
        return (
            <header className="header-fixed">
                <div className="header-content">
                    <div className="header-left">
                        <div className="logo"></div>
                        <div className='home-text'>首页</div>
                        <a className="download-text" href='href="/apps?utm_medium=desktop&utm_source=navbar-apps"'>下载APP</a>
                        <Input className={focused ? 'focused' : 'normal'} placeholder='请输入' suffix={
                            <InfoCircleOutlined style={{ color: 'rgba(0,0,0,.45)' }} />
                        }
                            onFocus={() => handleInputFocus()} onBlur={handleInputBlur}></Input>
                    </div>
                    <div className="">
                        <div className={focused ? 'focused' : ''}>asas</div>
                    </div>
                </div>
            </header>
        )
    }

}

const mapStateToProps = (state) => {
    return {
        focused: state.getIn(['header', 'focused']),
        list: state.getIn(['header', 'list'])
        // focused: state.get('header').get('focused')
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        handleInputFocus() {
            dispatch(actionCreators.searchFocus())
            dispatch(actionCreators.getList())
        },

        handleInputBlur() {
            dispatch(actionCreators.searchBlur())
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Header);